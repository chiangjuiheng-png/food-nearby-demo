const statusEl = document.getElementById("status");
const resultsEl = document.getElementById("results");
const locBtn = document.getElementById("locBtn");
const searchBtn = document.getElementById("searchBtn");

let userLat = null;
let userLng = null;

// 模擬店家資料（台北附近）
const shops = [
  { name: "阿財滷肉飯", type: "小吃", lat: 25.0330, lng: 121.5654 },
  { name: "一蘭拉麵", type: "拉麵", lat: 25.0342, lng: 121.5648 },
  { name: "深夜咖啡館", type: "咖啡", lat: 25.0321, lng: 121.5669 },
  { name: "麻辣火鍋店", type: "火鍋", lat: 25.0355, lng: 121.5678 }
];

locBtn.onclick = () => {
  if (!navigator.geolocation) {
    statusEl.textContent = "此裝置不支援定位";
    return;
  }

  statusEl.textContent = "定位中…";
  navigator.geolocation.getCurrentPosition(
    pos => {
      userLat = pos.coords.latitude;
      userLng = pos.coords.longitude;
      statusEl.textContent = "定位成功，請按查詢";
    },
    () => statusEl.textContent = "定位失敗，請允許定位"
  );
};

searchBtn.onclick = () => {
  if (userLat === null) {
    statusEl.textContent = "請先取得位置";
    return;
  }

  const type = document.getElementById("typeSelect").value;
  const radius = Number(document.getElementById("radiusSelect").value);

  const filtered = shops
    .map(s => ({ ...s, dist: distanceKm(userLat, userLng, s.lat, s.lng) }))
    .filter(s => s.dist <= radius && (type === "全部" || s.type === type))
    .sort((a, b) => a.dist - b.dist);

  resultsEl.innerHTML = "";
  if (!filtered.length) {
    statusEl.textContent = "附近沒有符合的店家";
    return;
  }

  statusEl.textContent = `找到 ${filtered.length} 間店`;
  filtered.forEach(s => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `<h3>${s.name}</h3><p>${s.type} · 約 ${s.dist.toFixed(2)} km</p>`;
    resultsEl.appendChild(div);
  });
};

function distanceKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat/2) ** 2 +
    Math.cos(lat1 * Math.PI / 180) *
    Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}
